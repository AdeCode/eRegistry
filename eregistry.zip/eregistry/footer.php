<!-- footer -->
<section class="w3-bottom copyright py-4" style="background-color:#fff;">
	<div class="agileits_w3layouts-copyright text-center">
		<p>Copyright 
		</p>
	</div>
</section>
<!-- //footer -->
<!-- js -->
<script type="text/javascript" src="./js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="./js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
<!-- //js -->


</body>
</html>