<?php 
	echo "processing...";
	$leave_type = $_POST["leave_type"];
	echo $leave_type;
?>