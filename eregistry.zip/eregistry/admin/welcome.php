<!-- User Welcome Message-->
<section class="w3-row">
    <!-- Left Spacer -->
    <div class="w3-col l3">
        &nbsp;
    </div>

    <!-- Welcome Image -->
    <div class="w3-col l6">
        <div class="w3-margin w3-text-dark-gray" style="min-height: 200px;">
            <img src="../img/user_wlcome.png">            
        </div>
    </div>

    <!-- Right Spacer -->
    <div class="w3-col l3">
        &nbsp;
    </div>
</section>
<section class="w3-row w3-padding w3-hide-large">&nbsp;</section>
<p>&nbsp;</p>
<!-- //User Welcome Message-->