<!-- 4 tablets and laptops -->
<div class="w3-container w3-display-middle w3-hide-small" style="width:30%; min-width:400px">    
  <div class="w3-card-4 w3-white">
    <div class="w3-container w3-blue-grey">
        <img src="img/sitaLogo.png" class="w3-image" alt="Sita Logo">
      	<h3 align="center">ABOUT</h3>
    </div>
      
  </div>
</div>



<!-- 4 phones -->
<div class="w3-container w3-display-middle w3-hide-medium w3-hide-large" style="max-width:1100px; width:100%">
  <div class="w3-card-4 w3-white">
    <div class="w3-container w3-blue-grey">
    	<img src="img/sitaLogo.png" class="w3-image" alt="Sita Logo">
      <h6 align="center">ABOUT</h6>
    </div>   
  </div>
</div>