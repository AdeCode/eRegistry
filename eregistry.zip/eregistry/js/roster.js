function check_entry(val){
    if (val.length != 0){
        document.getElementById("showResult").innerHTML="<center style='color:#f00;'> Please select an option </center>";
        return;
    }
    
}